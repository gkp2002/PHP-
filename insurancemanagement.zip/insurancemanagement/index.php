<html>
<head>
<title>
Life Insurance 
</title>
<!--mycode-->
<style>
	#linksToData{
		font-size: 70%;
		color:blue;
	}
	#heading{
		color:blueviolet;
	}
	body{
		background-image: url("insurance3.jpg");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
  background-repeat: no-repeat;
  background-attachment: fixed;
	}
	
</style><!--end of my code-->
</head>
<body>
<link href = "policy/registration.css" type = "text/css" rel = "stylesheet" />  
<link href = "style.css" type = "text/css" rel = "stylesheet" />  

<nav> 

<ul>
	<li><a href="agent/agent.php"> <h3 style="color:#EB59A1;">Agent Registration</h3></a></li>
	<li><a href="client/client.php"><h3 style="color:#EB59A1;"> Client Registration</h3></a></li>
	<li><a href="policy/policy.php"><h3 style="color: #EB59A1;"> Policy Registration</h3></a></li>
	<li><a href="premium/premium.php"><h3 style="color:#EB59A1;"> Premium Registration</h3></a></li>
	<li><a href="agent/modified1.php"><h3 style="color:#EB59A1;"> Agents Data</h3></a></li>
	
</ul>

</nav> 
<div class="title">
<h1 id="heading"><center>Life Insurance Management</center></h1>
</div>
<div class="links">
<div class="subtitle">
<!--<h2 id="linksToData"><center>Links to Data's and registration pages</center></h2>-->
<h2 id="linksToData"><center>Links to Data's and registration </center></h2>
</div>

<ul style="position: fixed; bottom: 0; width: 100%;">
	<li><a href="client/modified1.php"><h3 style="color:#EB59A1;"> Customers Data</h3></a></li>
	<li><a href="policy/modified1.php"><h3 style="color: #EB59A1;"> Policies Data</h3></a></li>
	<li><a href="premium/modified1.php"><h3 style="color:#EB59A1;"> Premiums Data</h3></a></li>
</ul>

</div>